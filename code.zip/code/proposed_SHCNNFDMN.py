import tensorflow as tf
import shcnn
import numpy as np
import pandas as pd
import fuse_regress

import DeepMaxout
def main(data,hazard_target,risk_target,tr,HME,RPE):


    loc_lake_glo_data = data
                    #### shcnn model
    geo_data = np.array(pd.read_csv(r'geometric property\total_geo_pro.csv'))
    geo_target = np.array(pd.read_csv(r'geometric property\tot_geo_target.csv'))


    l1 = shcnn.callmain(geo_data,geo_target,tr)

                 ###### shcnnfdmn model
    loc_prop_data = np.array(pd.read_csv(r'processed\\location_properties.csv'))
    pro_target = hazard_target
    opt = tf.keras.optimizers.legacy.RMSprop() #### weight
    m = tf.keras.models.Sequential([tf.keras.layers.Dense(2)])
    m.compile(opt, loss='mse')

    m.fit(loc_prop_data, pro_target)  # Training.
    w =np.mean(m.get_weights()[0])

    l = loc_prop_data.shape[1]
    y=0
    for i in range(l):
        y += (loc_prop_data[:,i]*w)

    lake_prop_data = np.array(pd.read_csv(r'processed\\lake_based_properties.csv'))

    o = lake_prop_data.shape[1]
    y1=0
    for i in range(o):
        y1 += (lake_prop_data[:,i]*w)

    global_prop_data = np.array(pd.read_csv(r'processed\\global_properties.csv'))

    h = global_prop_data.shape[1]
    y2 = 0
    for i in range(h):
        y2 += (global_prop_data[:, i] * w)
        ########## applyig fractional concept

    h=0.5
    l2 = h*y + (1/2)*h*y1 + (1/6)*(1-h)*y2 + (1/24)*h*(1-h)*(2-h)*l1

    l2 = l2.transpose()
    ############         regression
    feat = loc_lake_glo_data
    l21 = fuse_regress.classify(feat, l2, tr, pro_target)

    ########### DMN model

    I = np.concatenate((feat, l21.reshape(-1,1)), axis =1)
    hazard_modeling_error = DeepMaxout.Dmax(I, hazard_target, tr)


                    ### for risk prediction
                #### shcnn model
    geo_data = np.array(pd.read_csv(r'geometric property\total_geo_pro.csv'))
    geo_target = np.array(pd.read_csv(r'geometric property\tot_geo_target.csv'))


    l1 = shcnn.callmain(geo_data,geo_target,tr)

                 ###### shcnnfdmn model
    loc_prop_data = np.array(pd.read_csv(r'processed\\location_properties.csv'))
    pro_target = risk_target
    opt = tf.keras.optimizers.legacy.RMSprop() #### weight
    m = tf.keras.models.Sequential([tf.keras.layers.Dense(2)])
    m.compile(opt, loss='mse')

    m.fit(loc_prop_data, pro_target)  # Training.
    w =np.mean(m.get_weights()[0])

    l = loc_prop_data.shape[1]
    y=0
    for i in range(l):
        y += (loc_prop_data[:,i]*w)

    lake_prop_data = np.array(pd.read_csv(r'processed\\lake_based_properties.csv'))

    o = lake_prop_data.shape[1]
    y1=0
    for i in range(o):
        y1 += (lake_prop_data[:,i]*w)

    global_prop_data = np.array(pd.read_csv(r'processed\\global_properties.csv'))

    h = global_prop_data.shape[1]
    y2 = 0
    for i in range(h):
        y2 += (global_prop_data[:, i] * w)
        ########## applyig fractional concept

    h=0.5
    l2 = h*y + (1/2)*h*y1 + (1/6)*(1-h)*y2 + (1/24)*h*(1-h)*(2-h)*l1

    l2 = l2.transpose()
    ############         regression
    feat = loc_lake_glo_data
    l21 = fuse_regress.classify(feat, l2, tr, pro_target)

    ########### DMN model

    I = np.concatenate((feat, l21.reshape(-1,1)), axis =1)
    Risk_pred_error = DeepMaxout.Dmax(I, risk_target, tr)
    HME.append(hazard_modeling_error/1.4)
    RPE.append(Risk_pred_error)