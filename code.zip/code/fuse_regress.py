import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

def classify(Fea,L,tr,label):
    L = np.resize(L,(len(L),1))
    Data=np.concatenate((Fea,L),axis=1)




    X_train, y_train = Data,label



    reg=LinearRegression().fit(X_train, y_train)
    Prediction=(reg.predict(X_train)).flatten()
    Prediction = Prediction.astype(int)



    return Prediction
