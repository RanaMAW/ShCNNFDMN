import cv2 as cv
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import imutils


def draw_grid(img):
    line_color = (0, 255, 0)
    thickness = 1
    type_ = cv.LINE_AA
    pxstep = 25
    '''(ndarray, 3-tuple, int, int) -> void
    draw gridlines on img
    line_color:
        BGR representation of colour
    thickness:
        line thickness
    type:
        8, 4 or cv2.LINE_AA
    pxstep:
        grid line frequency in pixels
    '''
    x = pxstep
    y = pxstep
    while x < img.shape[1]:
        cv.line(img, (x, 0), (x, img.shape[0]), color=line_color, lineType=type_, thickness=thickness)
        x += pxstep

    while y < img.shape[0]:
        cv.line(img, (0, y), (img.shape[1], y), color=line_color, lineType=type_, thickness=thickness)
        y += pxstep
    return img


import os


def grid(path1, path2):
    listing = os.listdir(path1)
    for file in listing:
        filename = os.path.join(path1, file)
        img = cv.imread(filename)
        # img = imutils.resize(img, width=256)
        outputfile = path2 + '\\' + file[:-3] + 'png'

        # cv.imshow("Original image", img)

        copy_img = np.copy(img)
        copy_img = cv.cvtColor(copy_img, cv.COLOR_BGR2RGB)

        gray = cv.cvtColor(copy_img, cv.COLOR_RGB2GRAY)

        gray_blur = cv.GaussianBlur(gray, (11, 11), 0)

        # cv.imshow('Gaussian Blur', gray_blur)
        # cv.waitKey()

        kernel = np.ones((5, 5), np.uint8)
        img_erosion = cv.erode(gray_blur, kernel, iterations=1)
        # cv.imshow('After erode', img_erosion)

        lower = 60
        upper = 100
        adges = cv.Canny(img_erosion, lower, upper)

        # cv.imshow('Canny edge', adges)

        # plt.imshow(adges, cmap='gray')

        kernel2 = np.ones((5, 5), np.uint8)
        img_dilation = cv.dilate(adges, kernel2, iterations=1)

        # cv.imshow('Dilated image', img_dilation)

        kernel = np.ones((5, 5), np.uint8)
        img_erosion = cv.erode(gray_blur, kernel, iterations=1)
        import cv2

        s = draw_grid(img_erosion)

        cv2.imwrite(outputfile, s)

        # plt.imshow(s)
        # plt.show()


#
# grid(r'shp as png\1. glacial lake datasets',r'grid\1. glacial lake datasets')
# grid(r'shp as png\2. hazard and risk assessments',r'grid\2. hazard and risk assessments')
path1 = r'shp as png\1. glacial lake datasets'
listing = os.listdir(path1)
for file in listing:

    filename = os.path.join(path1, file)
    img = cv.imread(filename)
    n = int(np.ceil(img.shape[0] / 25))
    m = int(np.ceil(img.shape[1] / 25))
    gp = np.zeros((n, m))
    p, q, = 0, 25
    lab = []
    for i in range(n):

        r, s = 0, 25
        for j in range(m):
            if (i == n - 1) and (j == m - 1):
                if len(np.unique(img[p:q, r:s])) > 1:
                    gp[i, j] = 1
                else:
                    gp[i, j] = 0
            elif (j == m - 1):
                if len(np.unique(img[p:q, r:s])) > 1:
                    gp[i, j] = 1
                else:
                    gp[i, j] = 0
            elif (i == n - 1):
                if len(np.unique(img[p:q, r:s])) > 1:
                    gp[i, j] = 1
                else:
                    gp[i, j] = 0
            else:
                if len(np.unique(img[p:q, r:s])) > 1:
                    gp[i, j] = 1
                else:
                    gp[i, j] = 0

            r += 25
            s += 25

        if np.count_nonzero(gp[i, :] == 1) < 5:
            lab.append(0)

        elif 5 <= np.count_nonzero(gp[i, :] == 1) < 10:
            lab.append(1)
        elif 10 <= np.count_nonzero(gp[i, :] == 1) < 15:
            lab.append(2)
        elif 15 <= np.count_nonzero(gp[i, :] == 1) <= 19:
            lab.append(3)
        elif np.count_nonzero(gp[i, :] == 1) > 19:
            lab.append(4)
        p += 25
        q += 25

    gp1 = pd.DataFrame(gp)
    lab1 = pd.DataFrame(lab)
    outputfile1 = 'geometric property' + '\\' + file[:-4] + '_geometry_p' + '.csv'
    outputfile2 = 'geometric property' + '\\' + file[:-4] + '_target' + '.csv'
    lab1.to_csv(outputfile2, index=False)
    gp1.to_csv(outputfile1, index=False)





