
import os
import geopandas as gpd






def dbf_as_csv(path1,path2):
    listing = os.listdir(path1)
    for file in listing:
        if file[-3:]=='dbf':
            filename = os.path.join(path1, file)

            Table = gpd.read_file(filename)

            import pandas as pd
            Pandas_Table = pd.DataFrame(Table)
            outputfile     = path2 +'\\'+file[:-3]+'csv'
            Pandas_Table.to_csv(outputfile)
        else:
            pass
dbf_as_csv(r'dataset\\1. glacial lake datasets',r'dbf as csv\\1. glacial lake datasets')
dbf_as_csv(r'dataset\\2. hazard and risk assessments',r'dbf as csv\\2. hazard and risk assessments')
dbf_as_csv(r'dataset\\3. aggregated results',r'dbf as csv\\3. aggregated results')
dbf_as_csv(r'dataset\\4. transboundary threats',r'dbf as csv\\4. transboundary threats')


