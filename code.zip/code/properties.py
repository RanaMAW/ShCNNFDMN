import os
import pandas as pd
import numpy as np
##################  location properties
def loc_prop(path1,path2):
    listing = os.listdir(path1)
    filename = os.path.join(path1, listing[0])
    file = pd.read_csv(filename)
    k = file.iloc[:, 4:7]
    for i in range(1,len(listing)):
        filename = os.path.join(path1, listing[i])
        file = pd.read_csv(filename) ##### read csv
        ######### extracting the latitude longitude and altitude
        latitude = file['LAT']
        longitude = file['LON']
        altitude = file['ELEV']
        v = pd.concat([latitude, longitude, altitude], axis=1)
        k = pd.concat([k, v], axis=0)
    outputfile = path2 + '\\' +  'location_properties.csv'
    k.to_csv(outputfile,index = False) ####### to save it to csv file
# loc_prop(r'dbf as csv\1. glacial lake datasets',r'properties\1. glacial lake datasets')

####################### Lake based properties
def lake_basd_prop(path1,path2):
    listing = os.listdir(path1)
    filename = os.path.join(path1, listing[0])
    file = pd.read_csv(filename)
    k = file.iloc[:, 7:12]
    for i in range(1,len(listing)):

        filename = os.path.join(path1, listing[i])
        file = pd.read_csv(filename)

        #    extracting the lake based properties area, uncertainity ,perimeter ,water volume and lake type
        lake_area = file['AREA']
        uncertainity = file['E_AREA']
        perimetr = file['PERI']
        water_volume =file['VOLUME']
        lake_type =file['TYPE']

        v = pd.concat([lake_area, uncertainity, perimetr,water_volume,lake_type], axis=1)
        k = pd.concat([k, v], axis=0)
    outputfile = path2 + '\\' +  'lake_based_properties.csv'
    k.to_csv(outputfile,index = False) ####### to save it to csv file
# lake_basd_prop(r'dbf as csv\1. glacial lake datasets',r'properties\1. glacial lake datasets')

####################   global based properties
def global_prop(path1,path2):
    listing = os.listdir(path1)
    filename = os.path.join(path1, listing[0])
    file = pd.read_csv(filename)
    k = file.iloc[:, 12:14]
    for i in range(1,len(listing)):

        filename = os.path.join(path1, listing[i])
        file = pd.read_csv(filename)

        #  extracting the global based properties like utm and region

        UTM_grid_zone = file['UTM']
        GTN_G_region =file['REGION']

        v = pd.concat([UTM_grid_zone,GTN_G_region], axis=1)
        k = pd.concat([k, v], axis=0)
    outputfile = path2 + '\\' +  'global_properties.csv'
    k.to_csv(outputfile,index = False) ####### to save it to csv file

# global_prop(r'dbf as csv\1. glacial lake datasets',r'properties\1. glacial lake datasets')



def target(path1,path2):
    listing = os.listdir(path1)
    filename = os.path.join(path1, listing[0])
    file = pd.read_csv(filename)
    k = file['RISK']
    for i in range(1,len(listing)):

        filename = os.path.join(path1, listing[i])
        file = pd.read_csv(filename)


        risk = file['RISK']
        k = pd.concat([k, risk], axis=0)
    outputfile = path2 + '\\' +  'target.csv'
    k.to_csv(outputfile,index = False)####### to save it to csv file

