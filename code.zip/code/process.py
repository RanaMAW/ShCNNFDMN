import pandas as pd
# import os
filename = r'properties\\1. glacial lake datasets\\global_properties.csv'
df = pd.read_csv(filename)
unique =[]
import numpy as np
for i in range(len(df)):
    for j in range(df.shape[1]):
        if df.iloc[i, j] in unique:
            df.iloc[i, j] = unique.index(df.iloc[i, j])
        else:
            unique.append(df.iloc[i,j])
            df.iloc[i, j] = unique.index(df.iloc[i, j])
arr = np.array(df)
np.savetxt('processed\\global_properties.csv', arr, delimiter=',')


filename = r'properties\\1. glacial lake datasets\\lake_based_properties.csv'
df = pd.read_csv(filename)
unique =[]
for i in range(len(df)):

    if df.iloc[i, 4] in unique:
        df.iloc[i, 4] = unique.index(df.iloc[i, 4])
    else:
        unique.append(df.iloc[i,4])
        df.iloc[i, 4] = unique.index(df.iloc[i, 4])
arr = np.array(df)
np.savetxt('processed\\lake_based_properties.csv', arr, delimiter=',', fmt='%d')

filename = r'properties\\1. glacial lake datasets\\location_properties.csv'
df = pd.read_csv(filename)
arr = np.array(df)
np.savetxt('processed\\location_properties.csv', arr, delimiter=',', fmt='%d')


