from descartes import PolygonPatch
import matplotlib.pyplot as plt
import random
import shapefile
import sys
import os

def get_cmap(n, name='hsv'):
    '''Returns a function that maps each index in 0, 1, ..., n-1 to a distinct
    RGB color; the keyword argument name must be a standard mpl colormap name.'''
    return plt.cm.get_cmap(name, n)

# if len(sys.argv)!=3:
#   print("Syntax: {0} <Shapefile> <Output>".format(sys.argv[0]))
#   sys.exit(-1)

def shp_as_png(path1,path2):
    listing = os.listdir(path1)
    for file in listing:
        if file[-3:] =='shp':
            filename = os.path.join(path1, file)


            shapefile_name = filename
            assert os.path.exists(shapefile_name), "Input file does not exist."
            outputfile     = path2 +'\\'+file[:-3]+'png'

            polys  = shapefile.Reader(shapefile_name)
            shapes = polys.shapes()
            cmap   = get_cmap(len(shapes))

            #Enable to randomize colours
            #random.shuffle(shapes)

            fig = plt.figure()
            ax  = fig.add_axes((0,0,1,1))

            for i,poly in enumerate(shapes):
              poly  = poly.__geo_interface__
              color = cmap(i)
              # ax.add_patch(PolygonPatch(poly, fc=None, ec="black", alpha=1, zorder=2))
              ax.add_patch(PolygonPatch(poly,color='white',lw=.3,edgecolor='k'))

            ax.axis('scaled')
            ax.set_axis_off()
            plt.savefig(outputfile, bbox_inches='tight', pad_inches=0)
        else:
            pass

shp_as_png(r'dataset\\1. glacial lake datasets',r'shp as png\\1. glacial lake datasets')

