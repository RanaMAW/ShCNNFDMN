import numpy as np
import pandas as pd
import proposed_SHCNNFDMN

def callmain(tp):
    HME, RPE = [], []
    data = np.array(pd.read_csv('data.csv'))
    hazard_target = np.array(pd.read_csv('target_hazard.csv'))
    risk_target = np.array(pd.read_csv('risk_target.csv'))


    proposed_SHCNNFDMN.main(data, hazard_target, risk_target, tp, HME, RPE)

    return HME, RPE
tr= 0.5  ######  training data
callmain(tr)